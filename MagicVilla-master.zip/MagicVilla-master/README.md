# MagicVilla
MagicVilla Project : Creating a REST API and Consuming it in the ASP.NET Core MVC
